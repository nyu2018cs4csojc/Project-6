#define GL_SILENCE_DEPRECATION

#ifdef _WINDOWS
#include <GL/glew.h>
#endif

#define GL_GLEXT_PROTOTYPES 1
#include <SDL.h>
#include <SDL_opengl.h>
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "ShaderProgram.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include <SDL_mixer.h>
#include <vector>
using namespace std;

SDL_Window* displayWindow;
bool gameIsRunning = true;
bool started = false;

ShaderProgram program;
glm::mat4 viewMatrix, projectionMatrix;
#define FIXED_TIMESTEP 0.016f
float lastTicks = 0;
float accumulator = 0.0f;
float endtime = 0;
GLuint TextureIDFont;
GLuint TextureIDMap;
GLuint TextureIDPlayer1;
GLuint TextureIDPlayer2;
GLuint TextureIDEnemy;
GLuint TextureIDHeart;
GLuint TextureIDKey;
GLuint TextureIDDoor;
Mix_Music* mainmusic;
Mix_Music* losemusic;
Mix_Music* winmusic;
Mix_Chunk* heartsound;
Mix_Chunk* keysound;
bool lost = false;
bool won = false;
int counter = 0;

class Entity
{
public:
    glm::mat4 modelMatrix;
    GLuint TextureID;
    float vertices[12];
    float texcoords[12];
    glm::vec3 position;
    glm::vec3 velocity;
    glm::vec3 acceleration;
    bool found;
    float lower;
    float upper;
    Entity()
    {
        modelMatrix = glm::mat4(1.0f);
        velocity = glm::vec3(0);
        acceleration = glm::vec3(0);
    }
    Entity(glm::vec3 p, float w, float h, GLuint t) : texcoords{ 0, h, w, h, w, 0, 0, h, w, 0, 0, 0 }, vertices{ -w / 2, -h / 2, w / 2, -h / 2, w / 2, h / 2, -w / 2, -h / 2, w / 2, h / 2, -w / 2, h / 2 }
    {
        modelMatrix = glm::mat4(1.0f);
        velocity = glm::vec3(0);
        acceleration = glm::vec3(0);
        position = p;
        TextureID = t;
        modelMatrix = glm::translate(modelMatrix, position);
    }
    Entity(float u, float v, glm::vec3 p) : texcoords{ u, v + 0.0625f, u + 0.0625f, v + 0.0625f, u + 0.0625f, v, u, v + 0.0625f, u + 0.0625f, v, u, v }, vertices{ -0.5, -0.5, 0.5, -0.5, 0.5, 0.5, -0.5, -0.5, 0.5, 0.5, -0.5, 0.5 }
    {
        TextureID = TextureIDFont;
        modelMatrix = glm::mat4(1.0f);
        velocity = glm::vec3(0);
        acceleration = glm::vec3(0);
        position = p;
        modelMatrix = glm::translate(modelMatrix, position);
    }
    Entity(glm::vec3 p, float l, float u, bool vertical): texcoords{ 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0 }, vertices{ -0.5, -0.5, 0.5, -0.5, 0.5, 0.5, -0.5, -0.5, 0.5, 0.5, -0.5, 0.5 }
    {
        TextureID = TextureIDEnemy;
        modelMatrix = glm::mat4(1.0f);
        velocity = glm::vec3(0);
        if (vertical) { velocity.y = 1; }
        else { velocity.x = 1; }
        acceleration = glm::vec3(0);
        position = p;
        modelMatrix = glm::translate(modelMatrix, position);
        found = vertical;
        lower = l;
        upper = u;
    }
    void Update(float deltaTime)
    {
        velocity += acceleration * deltaTime;
        position += velocity * deltaTime;
        modelMatrix = glm::mat4(1.0f);
        modelMatrix = glm::translate(modelMatrix, position);
    }
    void Render()
    {
        program.SetModelMatrix(modelMatrix);
        glVertexAttribPointer(program.positionAttribute, 2, GL_FLOAT, false, 0, vertices);
        glEnableVertexAttribArray(program.positionAttribute);
        glVertexAttribPointer(program.texCoordAttribute, 2, GL_FLOAT, false, 0, texcoords);
        glEnableVertexAttribArray(program.texCoordAttribute);
        glBindTexture(GL_TEXTURE_2D, TextureID);
        glDrawArrays(GL_TRIANGLES, 0, 6);
        glDisableVertexAttribArray(program.positionAttribute);
        glDisableVertexAttribArray(program.texCoordAttribute);
    }
};

class Map
{
public:
    const int width;
    const int height;
    vector<vector<int>> leveldata;
    GLuint TextureID;
    Map(int width, int height, vector<vector<int>> texturedata) : width(width), height(height), TextureID(TextureIDMap)
    {
        for (int i = 0; i < height; i++)
        {
            vector<int> temp;
            for (int j = 0; j < width; j++)
            {
                temp.push_back(texturedata[i][j]);
            }
            leveldata.push_back(temp);
        }
    }
    void Build()
    {
        float w = 1.0f / 6;
        float h = 1.0f / 2;
        for (float y = 0; y < height; y++)
        {
            for (float x = 0; x < width; x++)
            {
                int tex = leveldata[int(y)][int(x)];
                float u = float(tex % 6) / 6;
                float v = float(tex / 6) / 2;
                float vertices[12] = { x, y, x + 1, y, x + 1, y + 1, x, y, x + 1, y + 1, x, y + 1 };
                float texcoords[12] = { u, v + h, u + w, v + h, u + w, v, u, v + h, u + w, v, u, v };
                Render(vertices, texcoords);
            }
        }
    }
    void Render(float vertices[12], float texcoords[12])
    {
        program.SetModelMatrix(glm::mat4(1.0f));
        glVertexAttribPointer(program.positionAttribute, 2, GL_FLOAT, false, 0, vertices);
        glEnableVertexAttribArray(program.positionAttribute);
        glVertexAttribPointer(program.texCoordAttribute, 2, GL_FLOAT, false, 0, texcoords);
        glEnableVertexAttribArray(program.texCoordAttribute);
        glBindTexture(GL_TEXTURE_2D, TextureIDMap);
        glDrawArrays(GL_TRIANGLES, 0, 6);
        glDisableVertexAttribArray(program.positionAttribute);
        glDisableVertexAttribArray(program.texCoordAttribute);
    }
    bool isObstacle(float y, float x)
    {
        if (leveldata[int(y)][int(x)] != 8)
        {
            return true;
        }
        return false;
    }
};

vector<Entity*> textassign(vector<Entity*> var, string message, float y, float x)
{
    float s, u, v;
    if (int(message.length()) % 2 == 0)
    {
        s = x - 5.0 / message.length() / 2.0 - 5.0 / message.length() * (message.length() / 2.0 - 1);
    }
    else
    {
        s = x - 5.0 / message.length() * int((message.length()) / 2.0);
    }
    for (int i = 0; i < message.length(); i++)
    {
        if (message[i] == ' ')
        {
            s += 5.0 / message.length(); continue;
        }
        u = (float)(message[i] % 16) / 16;
        v = (float)(message[i] / 16) / 16;
        var.push_back(new Entity(u, v, glm::vec3(s, y, 0)));
        s += 5.0 / message.length();
    }
    return var;
}

struct menu {
    vector<Entity*> title;
    vector<Entity*> subtitle;
    void Render()
    {
        for (Entity* i : title)
        {
            i->Render();
        }
        for (Entity* i : subtitle)
        {
            i->Render();
        }
    }
    ~menu()
    {
        for (Entity* i : title)
        {
            delete i;
        }
        title.clear();
        for (Entity* i : subtitle)
        {
            delete i;
        }
        subtitle.clear();
    }
};

struct maze {
    Map* map;
    Entity* player;
    vector<Entity*> text;
    Entity* enemies[4];
    Entity* lives[3];
    Entity* key[3];
    Entity* door;
    void Render()
    {
        program.SetViewMatrix(viewMatrix);
        map->Build();
        player->Render();
        door->Render();
        for (int i = 0; i < 3; i++)
        {
            if (lives[i] != nullptr) { lives[i]->Render(); }
            key[i]->Render();
        }
        for (Entity* i : enemies) { i->Render(); }
        if (lost || won) 
        { 
            for (Entity* i : text) 
            { i->Render(); } 
        }
    }
    void Update(float deltaTime)
    {
        //set player maze collision
        if (pow(pow(player->velocity.x, 2) + pow(player->velocity.y, 2), 0.5) > 1) 
        { player->velocity = glm::normalize(player->velocity); }
        if (map->isObstacle(player->position.y - 0.5, player->position.x - 0.5)) 
        { 
            if (player->velocity.x < 0) { player->velocity.x += 1; }
            if (player->velocity.y < 0) { player->velocity.y += 1; } 
        }
        if (map->isObstacle(player->position.y + 0.5, player->position.x - 0.5)) 
        { 
            if (player->velocity.x < 0) { player->velocity.x += 1; }
            if (player->velocity.y > 0) { player->velocity.y += -1; }
        }
        if (map->isObstacle(player->position.y - 0.5, player->position.x + 0.5)) 
        { 
            if (player->velocity.x > 0) { player->velocity.x += -1; }
            if (player->velocity.y < 0) { player->velocity.y += 1; }
        }
        if (map->isObstacle(player->position.y + 0.5, player->position.x + 0.5)) 
        { 
            if (player->velocity.x > 0) { player->velocity.x += -1; }
            if (player->velocity.y > 0) { player->velocity.y += -1; }
        }
        player->acceleration = player->velocity * glm::vec3(-1 / 1000);
        if (counter > 35)
        {
            if (player->TextureID == TextureIDPlayer1) {player->TextureID = TextureIDPlayer2;}
            else {player->TextureID = TextureIDPlayer1;}
            counter = 0;
        }
        else if (player->velocity != glm::vec3(0)) { counter++; }
        //enemy movement
        for (int i = 0; i < 4; i++)
        {
            if (enemies[i]->found)
            {
                if (enemies[i]->position.y < enemies[i]->lower || enemies[i]->position.y > enemies[i]->upper)
                {enemies[i]->velocity.y *= -1;}
            }
            else
            {
                if (enemies[i]->position.x < enemies[i]->lower || enemies[i]->position.x > enemies[i]->upper)
                {enemies[i]->velocity.x *= -1;}
            }
        }
        //key collision
        for (int i = 0; i < 3; i++)
        {
            if (abs(player->position.x - key[i]->position.x) < 1 && abs(player->position.y - key[i]->position.y) < 1 && !key[i]->found)
            {key[i]->found = true; Mix_PlayChannel(-1, keysound, 0);}
        }
        //enemy collision
        for (int i = 0; i < 4; i++)
        {
            if (abs(player->position.x - enemies[i]->position.x) < 1 && abs(player->position.y - enemies[i]->position.y) < 1)
            {
                int h = 2;
                while (lives[h] == nullptr) { h--; }
                delete lives[h];
                lives[h] = nullptr;
                if (enemies[i]->found &&
                    (enemies[i]->velocity.y < 0 && enemies[i]->position.y < enemies[i]->lower + 2
                        || enemies[i]->velocity.y > 0 && enemies[i]->position.y > enemies[i]->upper - 2)
                    || !enemies[i]->found &&
                    (enemies[i]->velocity.x < 0 && enemies[i]->position.x < enemies[i]->lower + 2
                        || enemies[i]->velocity.x > 0 && enemies[i]->position.x > enemies[i]->upper - 2))
                {
                    enemies[i]->velocity *= glm::vec3(-1);
                    enemies[i]->position += enemies[i]->velocity;
                }
                else
                {
                    enemies[i]->position += enemies[i]->velocity * glm::vec3(2);
                }
                player->velocity = glm::vec3(0);
                Mix_PlayChannel(-1, heartsound, 0);
            }
        }
        //update everything
        player->Update(deltaTime);
        for (Entity* i : enemies)
        {
            if (i != nullptr) { i->Update(deltaTime); }
        }
        for (Entity* i : lives)
        {
            if (i != nullptr) { i->Update(deltaTime); }
        }
        for (Entity* i : key)
        {
            if (i->found) { i->Update(deltaTime); }
        }
        //set view matrix
        float viewx = 2.5 - player->position.x;
        float viewy = 2.5 - player->position.y;
        if (player->position.x <= 2.5) { viewx = 0; }
        if (player->position.y <= 2.5) { viewy = 0; }
        if (player->position.x >= map->width - 2.5) { viewx = 5.0 - map->width; }
        if (player->position.y >= map->height - 2.5) { viewy = 5.0 - map->height; }
        viewMatrix = glm::translate(glm::mat4(1.0f), glm::vec3(viewx, viewy, 0));
        for (int i = 0; i < 3; i++)
        {
            if (lives[i] != nullptr) { lives[i]->modelMatrix = glm::translate(glm::mat4(1.0f), glm::vec3(-viewx + 1.5 + i, -viewy + 0.5, 0)); }
            if (key[i]->found) { key[i]->modelMatrix = glm::translate(glm::mat4(1.0f), glm::vec3(-viewx + 1.5 + i, -viewy + 4.5, 0)); }
        }
        //check for winning or losing
        if (door->position.y - player->position.y < 1 && abs(door->position.x - player->position.x) < 2)
        {
            if (key[0]->found && key[1]->found && key[2]->found)
            {
                won = true;
                Mix_PlayMusic(winmusic, -1);
                text = textassign(text, "You Win!", 2.5 - viewy, 2.5 - viewx);
            }
        }
        if (lives[0] == nullptr)
        {
            lost = true;
            Mix_PlayMusic(losemusic, -1);
            text = textassign(text, "You Lose", 2.5 - viewy, 2.5 - viewx);
        }
    }
};

maze game;
menu slide;

GLuint LoadTexture(const char* filePath) {
    int w, h, n;
    unsigned char* image = stbi_load(filePath, &w, &h, &n, STBI_rgb_alpha);
    if (image == NULL) {
        std::cout << "Unable to load image. Make sure the path is correct\n";
        assert(false);
    }
    GLuint textureID;
    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    stbi_image_free(image);
    return textureID;
}

void Initialize() {
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);
    displayWindow = SDL_CreateWindow("Maze Run!", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 640, 480, SDL_WINDOW_OPENGL);
    SDL_GLContext context = SDL_GL_CreateContext(displayWindow);
    SDL_GL_MakeCurrent(displayWindow, context);
#ifdef _WINDOWS
    glewInit();
#endif
    glViewport(0, 0, 640, 480);
    program.Load("shaders/vertex_textured.glsl", "shaders/fragment_textured.glsl");
    viewMatrix = glm::mat4(1.0f);
    projectionMatrix = glm::ortho(0.0f, 5.0f, 0.0f, 5.0f, -1.0f, 1.0f);
    program.SetProjectionMatrix(projectionMatrix);
    program.SetViewMatrix(viewMatrix);
    glUseProgram(program.programID);
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 4096);
    TextureIDFont = LoadTexture("font1.png");
    TextureIDMap = LoadTexture("tilemap_packed.png");
    TextureIDPlayer1 = LoadTexture("character_0006.png");
    TextureIDPlayer2 = LoadTexture("character_0007.png");
    TextureIDEnemy = LoadTexture("character_0021.png");
    TextureIDHeart = LoadTexture("tile_0044.png");
    TextureIDKey = LoadTexture("tile_0027.png");
    TextureIDDoor = LoadTexture("tile_0028.png");
    mainmusic = Mix_LoadMUS("music1.mp3");
    winmusic = Mix_LoadMUS("music2.mp3");
    losemusic = Mix_LoadMUS("music3.mp3");
    heartsound = Mix_LoadWAV("pop.wav");
    keysound = Mix_LoadWAV("clink.wav");
    slide.title = textassign(slide.title, "MAZERUN", 3.5, 2.5);
    slide.subtitle = textassign(slide.subtitle, "Press Enter to Start", 1.5, 2.5);
    vector<vector<int>> background = {
    {5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5},
    {5, 8, 8, 5, 8, 8, 8, 8, 8, 8, 5, 8, 8, 8, 8, 8, 8, 8, 8, 5},
    {5, 8, 8, 5, 8, 8, 8, 8, 8, 8, 5, 8, 8, 8, 8, 8, 8, 8, 8, 5},
    {5, 8, 8, 5, 5, 5, 8, 8, 5, 5, 5, 8, 8, 5, 5, 5, 5, 8, 8, 5},
    {5, 8, 8, 8, 8, 5, 8, 8, 8, 8, 8, 8, 8, 5, 8, 8, 5, 8, 8, 5},
    {5, 8, 8, 8, 8, 5, 8, 8, 8, 8, 8, 8, 8, 5, 8, 8, 5, 8, 8, 5},
    {5, 5, 5, 8, 8, 5, 5, 5, 5, 5, 8, 8, 5, 5, 8, 8, 8, 8, 8, 5},
    {5, 8, 8, 8, 8, 8, 8, 8, 8, 5, 8, 8, 8, 5, 8, 8, 8, 8, 8, 5},
    {5, 8, 8, 8, 8, 8, 8, 8, 8, 5, 8, 8, 8, 5, 5, 5, 5, 8, 8, 5},
    {5, 8, 8, 5, 5, 5, 5, 8, 8, 5, 5, 5, 5, 5, 8, 8, 5, 8, 8, 5},
    {5, 8, 8, 5, 8, 8, 5, 8, 8, 8, 8, 8, 8, 8, 8, 8, 5, 8, 8, 5},
    {5, 8, 8, 5, 8, 8, 5, 8, 8, 8, 8, 8, 8, 8, 8, 8, 5, 8, 8, 5},
    {5, 8, 8, 8, 8, 8, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 8, 8, 5},
    {5, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 5},
    {5, 5, 5, 5, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 5},
    {5, 8, 8, 5, 8, 8, 8, 5, 5, 8, 8, 5, 5, 8, 8, 5, 5, 8, 8, 5},
    {5, 8, 8, 5, 8, 8, 8, 5, 5, 8, 8, 5, 5, 8, 8, 5, 5, 8, 8, 5},
    {5, 8, 8, 8, 8, 8, 8, 5, 8, 8, 8, 8, 5, 8, 8, 8, 8, 8, 8, 5},
    {5, 8, 8, 8, 8, 8, 8, 5, 8, 8, 8, 8, 5, 8, 8, 8, 8, 8, 8, 5},
    {5, 5, 5, 5, 5, 5, 5, 5, 3, 3, 3, 3, 5, 5, 5, 5, 5, 5, 5, 5}};
    Map* m = new Map(20, 20, background);
    game.map = m;
    game.player = new Entity(glm::vec3(2.0, 1.5, 0), 1, 1, TextureIDPlayer1);
    for (int i = 0; i < 3; i++)
    {game.lives[i] = new Entity(glm::vec3(1.5 + i, 0.5, 0), 1, 1, TextureIDHeart);}
    game.door = new Entity(glm::vec3(10.0, 19.0, 0), 3, 1, TextureIDDoor);
    game.key[0] = new Entity(glm::vec3(2.0, 16.0, 0), 1, 1, TextureIDKey);
    game.key[1] = new Entity(glm::vec3(16.0, 18.0, 0), 1, 1, TextureIDKey);
    game.key[2] = new Entity(glm::vec3(5.0, 2.0, 0), 1, 1, TextureIDKey);
    for (int i = 0; i < 3; i++) { game.key[i]->found = false; }
    game.enemies[0] = new Entity(glm::vec3(5.0, 14.5, 0), 10.5, 18.5, true);
    game.enemies[1] = new Entity(glm::vec3(10.0, 14.0, 0), 6.5, 13.5, false);
    game.enemies[2] = new Entity(glm::vec3(18.0, 10.0, 0), 1.5, 18.5, true);
    game.enemies[3] = new Entity(glm::vec3(7.0, 2.0, 0), 4.5, 9.5, false);
    Mix_PlayMusic(mainmusic, -1);
}

void ProcessInput() {
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        switch (event.type)
        {
        case SDL_QUIT:
        case SDL_WINDOWEVENT_CLOSE:
            gameIsRunning = false;
            break;
        case SDL_KEYDOWN:
            if (event.key.keysym.sym == SDLK_RETURN && !started)
            {
                glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
                started = true;
            }
            break;
        }
    }
    const Uint8* keys = SDL_GetKeyboardState(NULL);
    if (keys[SDL_SCANCODE_LEFT])
    {
        game.player->velocity.x += -1.0f;
    }
    if (keys[SDL_SCANCODE_RIGHT])
    {
        game.player->velocity.x += 1.0f;
    }
    if (keys[SDL_SCANCODE_UP])
    {
        game.player->velocity.y += 1.0f;
    }
    if (keys[SDL_SCANCODE_DOWN])
    {
        game.player->velocity.y += -1.0f;
    }
}

void Update()
{
    float ticks = (float)SDL_GetTicks() / 1000.0f;
    float deltaTime = ticks - lastTicks;
    lastTicks = ticks;
    deltaTime += accumulator;
    if (deltaTime < FIXED_TIMESTEP)
    {
        accumulator = deltaTime;
        return;
    }
    while (deltaTime >= FIXED_TIMESTEP)
    {
        if (started && !won && !lost) { game.Update(FIXED_TIMESTEP); }
        deltaTime -= FIXED_TIMESTEP;
    }
    accumulator = deltaTime;
}

void Render() {
    glClear(GL_COLOR_BUFFER_BIT);
    if (!started){slide.Render();}
    else {game.Render();}
    SDL_GL_SwapWindow(displayWindow);
}

void Shutdown() {
    SDL_Quit();
}

int main(int argc, char* argv[]) {
    Initialize();
    while (gameIsRunning) {
        ProcessInput();
        Update();
        Render();
    }
    Shutdown();
    return 0;
}